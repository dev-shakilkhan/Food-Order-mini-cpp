#include <iostream>
#include<string>
#include <vector>
#include <fstream>
#include <iomanip>

using namespace std;

// Class to represent a Menu Item
class MenuItem {
public:
    int id;
    string name;
    double price;

    MenuItem(int id, string name, double price) {
        this->id = id;
        this->name = name;
        this->price = price;
    }
};

// Class to represent a Customer
class Customer {
public:
    string name;

    Customer(string name) {
        this->name = name;
    }
};

// Class to represent an Order
class Order {
private:
    Customer customer;
    vector<MenuItem> menu;
    vector<MenuItem> cart;

public:
    Order(Customer c, vector<MenuItem> menuItems) : customer(c), menu(menuItems) {}

    void showMenu() {
        cout << "\n===== MENU =====\n";
        cout << left << setw(5) << "ID" << setw(20) << "Name" << "Price\n";
        for (auto& item : menu) {
            cout << left << setw(5) << item.id << setw(20) << item.name << "$" << item.price << endl;
        }
    }

    void addItemToCart(int id) {
        for (auto& item : menu) {
            if (item.id == id) {
                cart.push_back(item);
                cout << item.name << " added to your order.\n";
                return;
            }
        }
        cout << "Invalid item ID.\n";
    }

    void generateBill() {
        double total = 0;
        cout << "\n===== BILL =====\n";
        cout << "Customer: " << customer.name << "\n";
        cout << left << setw(20) << "Item" << "Price\n";
        for (auto& item : cart) {
            cout << left << setw(20) << item.name << "$" << item.price << endl;
            total += item.price;
        }
        cout << "\nTotal: $" << total << "\n";

        // Save to file
        ofstream file("orders.txt", ios::app);
        file << "Customer: " << customer.name << "\n";
        for (auto& item : cart) {
            file << item.name << " - $" << item.price << "\n";
        }
        file << "Total: $" << total << "\n\n";
        file.close();
    }
};

// Main Function
int main() {
    vector<MenuItem> menu = {
        MenuItem(1, "Burger", 5.99),
        MenuItem(2, "Pizza", 8.99),
        MenuItem(3, "Pasta", 6.49),
        MenuItem(4, "Soda", 1.99),
        MenuItem(5, "Ice Cream", 2.99)
    };

    string customerName;
    cout << "Welcome to the Online Food Ordering System!\n";
    cout << "Enter your name: ";
    getline(cin, customerName);
    Customer customer(customerName);
    Order order(customer, menu);

    int choice;
    do {
        order.showMenu();
        cout << "Enter the item ID to add to your order (0 to finish): ";
        cin >> choice;
        if (choice != 0) {
            order.addItemToCart(choice);
        }
    } while (choice != 0);

    order.generateBill();
    cout << "\nThank you for your order!\n";

    return 0;
}
