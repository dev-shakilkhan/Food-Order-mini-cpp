# This is version 1.1 . It's features are
    - Take name
    - Take order
    - disply bill 
    - store bill