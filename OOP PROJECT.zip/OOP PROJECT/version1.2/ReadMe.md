# This is version 1.2 . It's features are
### previous Featurs of version_1.1
    - Take name
    - Take order
    - disply bill 
    - store bill
### Improvements of version_1.2
    - It takes quantity of items.