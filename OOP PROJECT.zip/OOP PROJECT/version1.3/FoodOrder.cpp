#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <sstream>

using namespace std;

// Class to represent a Menu Item
class MenuItem {
public:
    int id;
    string name;
    double price;

    MenuItem(int id, string name, double price) {
        this->id = id;
        this->name = name;
        this->price = price;
    }
};

// Struct to represent an Ordered Item with Quantity
struct OrderedItem {
    MenuItem item;
    int quantity;

    OrderedItem(MenuItem item, int quantity) : item(item), quantity(quantity) {}
};

// Class to represent a Customer
class Customer {
public:
    string name;

    Customer(string name) {
        this->name = name;
    }
};

// Class to represent an Order
class Order {
private:
    Customer customer;
    vector<MenuItem> menu;
    vector<OrderedItem> cart;
    string orderID;
    string orderTimestamp;

    // Generate current timestamp
    string generateTimestamp() {
        time_t now = time(0);
        tm* ltm = localtime(&now);

        char buffer[30];
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", ltm);
        return string(buffer);
    }

    // Generate unique Order ID using time
    string generateOrderID() {
        time_t now = time(0);
        tm* ltm = localtime(&now);
        stringstream ss;
        ss << "ORD"
           << (1900 + ltm->tm_year)
           << setw(2) << setfill('0') << (1 + ltm->tm_mon)
           << setw(2) << setfill('0') << ltm->tm_mday
           << setw(2) << setfill('0') << ltm->tm_hour
           << setw(2) << setfill('0') << ltm->tm_min
           << setw(2) << setfill('0') << ltm->tm_sec;
        return ss.str();
    }

public:
    Order(Customer c, vector<MenuItem> menuItems)
        : customer(c), menu(menuItems) {
        orderID = generateOrderID();
        orderTimestamp = generateTimestamp();
    }

    void showMenu() {
        cout << "\n===== MENU =====\n";
        cout << left << setw(5) << "ID" << setw(20) << "Name" << "Price\n";
        for (auto& item : menu) {
            cout << left << setw(5) << item.id << setw(20) << item.name << "$" << item.price << endl;
        }
    }

    void addItemToCart(int id, int quantity) {
        for (auto& item : menu) {
            if (item.id == id) {
                cart.emplace_back(item, quantity);
                cout << quantity << " x " << item.name << " added to your order.\n";
                return;
            }
        }
        cout << "Invalid item ID.\n";
    }

    void generateBill() {
        double total = 0;
        cout << "\n===== BILL =====\n";
        cout << "Order ID: " << orderID << "\n";
        cout << "Timestamp: " << orderTimestamp << "\n";
        cout << "Customer: " << customer.name << "\n\n";

        cout << left << setw(20) << "Item" << setw(10) << "Qty" << setw(10)
             << "Price" << "Total\n";

        for (auto& ordered : cart) {
            double itemTotal = ordered.item.price * ordered.quantity;
            cout << left << setw(20) << ordered.item.name
                 << setw(10) << ordered.quantity
                 << "$" << setw(9) << ordered.item.price
                 << "$" << itemTotal << endl;
            total += itemTotal;
        }

        cout << "\nGrand Total: $" << total << "\n";

        // Save to file
        ofstream file("orders.txt", ios::app);
        file << "----------------------------------------\n";
        file << "Order ID: " << orderID << "\n";
        file << "Timestamp: " << orderTimestamp << "\n";
        file << "Customer: " << customer.name << "\n";
        for (auto& ordered : cart) {
            double itemTotal = ordered.item.price * ordered.quantity;
            file << ordered.item.name << " x" << ordered.quantity
                 << " - $" << itemTotal << "\n";
        }
        file << "Total: $" << total << "\n";
        file << "----------------------------------------\n\n";
        file.close();
    }
};

// Main Function
int main() {
    vector<MenuItem> menu = {
        MenuItem(1, "Burger", 5.99),
        MenuItem(2, "Pizza", 8.99),
        MenuItem(3, "Pasta", 6.49),
        MenuItem(4, "Soda", 1.99),
        MenuItem(5, "Ice Cream", 2.99)
    };

    string customerName;
    cout << "Welcome to the Online Food Ordering System!\n";
    cout << "Enter your name: ";
    cin.ignore();
    getline(cin, customerName);

    Customer customer(customerName);
    Order order(customer, menu);

    int choice, quantity;
    do {
        order.showMenu();
        cout << "Enter the item ID to add to your order (0 to finish): ";
        cin >> choice;
        if (choice != 0) {
            cout << "Enter quantity: ";
            cin >> quantity;
            if (quantity > 0)
                order.addItemToCart(choice, quantity);
            else
                cout << "Quantity must be greater than 0.\n";
        }
    } while (choice != 0);

    order.generateBill();
    cout << "\nThank you for your order!\n";

    return 0;
}
